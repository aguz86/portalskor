import { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  Link,
} from "react-router-dom";
import { supabase } from "./supabase";
import { supabaseService } from "./services/supabaseService";
import { UserProfile } from "./types";
import Home from "./pages/Home";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";
import Landing from "./pages/Landing";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Install from "./pages/Install";
import {
  LogOut,
  Shield,
  Trophy,
  Facebook,
  Instagram,
  Youtube,
  Music4,
  Lock,
} from "lucide-react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isInstalled, setIsInstalled] = useState<boolean | null>(null);
  const [webName, setWebName] = useState("Portal Skor");
  const [adminEmail, setAdminEmail] = useState("");
  const [appConfig, setAppConfig] = useState<any>(null);

  useEffect(() => {
    // Fallback timeout to prevent infinite loading pop-up if Supabase auth hangs
    const loadingTimeout = setTimeout(() => {
      setLoading(false);
      setIsInstalled((prev) => (prev === null ? false : prev));
    }, 5000);

    // Check installation status
    const fetchConfig = async () => {
      if (
        import.meta.env.VITE_SUPABASE_URL &&
        import.meta.env.VITE_SUPABASE_ANON_KEY
      ) {
        try {
          const config = await supabaseService.getConfig();
          if (config) {
            setIsInstalled(true);
            setWebName(config.webName || "Portal Skor");
            setAdminEmail(config.adminEmail || "");
            setAppConfig(config);
            return;
          }
        } catch (error) {
          console.error("Supabase config fetch error:", error);
        }
      }

      setIsInstalled(false);
    };

    fetchConfig();

    const hasConfig = !!(
      import.meta.env.VITE_SUPABASE_URL &&
      import.meta.env.VITE_SUPABASE_ANON_KEY
    );
    let configSubscription: any = null;
    let authSubscription: any = null;

    if (hasConfig) {
      // Subscribe to config changes in Supabase
      configSubscription = supabase
        .channel("settings_changes")
        .on(
          "postgres_changes",
          {
            event: "UPDATE",
            schema: "public",
            table: "settings",
            filter: "id=eq.config",
          },
          (payload) => {
            const data = payload.new as any;
            setWebName(data.webname || "Portal Skor");
            setAdminEmail(data.adminemail || "");
            setAppConfig((prev: any) => ({
              ...prev,
              webName: data.webname,
              adminEmail: data.adminemail,
              logoUrl: data.logo_url,
              facebookUrl: data.facebook_url,
              youtubeUrl: data.youtube_url,
              instagramUrl: data.instagram_url,
              tiktokUrl: data.tiktok_url,
              bannerImageUrl: data.banner_image_url,
              bannerLinkUrl: data.banner_link_url,
            }));
          },
        )
        .subscribe();

      // Listen for auth changes
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === "SIGNED_IN" && session?.user) {
          const profile = await supabaseService.getUserProfile(session.user.id);
          setUser(profile);
        } else if (event === "SIGNED_OUT") {
          setUser(null);
        }
      });
      authSubscription = subscription;
    }

    const checkAuth = async () => {
      try {
        if (hasConfig) {
          try {
            const {
              data: { session },
            } = await supabase.auth.getSession();
            if (session?.user) {
              const profile = await supabaseService.getUserProfile(
                session.user.id,
              );
              if (profile) {
                setUser(profile);
                setLoading(false);
                return;
              } else {
                // Profile missing but Auth successful. Create profile!
                const config = await supabaseService.getConfig();
                const adminEmail = config?.adminEmail || "";
                const role =
                  session.user.email === adminEmail ? "admin" : "user";
                const username = (
                  session.user.user_metadata?.username ||
                  session.user.email?.split("@")[0] ||
                  "User"
                )
                  .replace(/[^a-zA-Z0-9]/g, "")
                  .slice(0, 8);

                const newProfile = {
                  uid: session.user.id,
                  username,
                  email: session.user.email || "",
                  role,
                  balance: 0,
                };

                const { error: profileError } = await supabase
                  .from("users")
                  .insert([newProfile]);

                if (!profileError) {
                  setUser(newProfile as UserProfile);
                  setLoading(false);
                  return;
                }
              }
            }
          } catch (e) {
            // No Supabase session
          }
        }

        setUser(null);
      } catch (error) {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();

    return () => {
      clearTimeout(loadingTimeout);
      if (configSubscription) configSubscription.unsubscribe();
      if (authSubscription) authSubscription.unsubscribe();
    };
  }, []);

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  useEffect(() => {
    // We don't dynamically append the reset install button anymore to avoid pop ups.
  }, [loading, isInstalled]);

  if (loading || isInstalled === null) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950 text-white">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
          <div id="loader-container"></div>
        </div>
      </div>
    );
  }

  if (!isInstalled) {
    if (window.location.pathname === "/install") {
      return <Install onComplete={() => (window.location.href = "/")} />;
    }

    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-950 p-4 font-sans text-center">
        <div className="max-w-md w-full bg-zinc-900 border border-white/10 rounded-[40px] p-8 shadow-2xl space-y-6">
          <div className="p-4 bg-amber-500/10 rounded-2xl w-fit mx-auto">
            <Lock className="w-10 h-10 text-amber-500" />
          </div>
          <h1 className="text-2xl font-black text-white">
            Website Sedang Diperbaiki
          </h1>
          <p className="text-zinc-400 text-sm">
            Sistem kami saat ini sedang dalam pemeliharaan. Silakan kembali lagi
            nanti.
          </p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-500/30">
        {user && (
          <nav className="border-b border-white/5 bg-zinc-900/50 backdrop-blur-xl sticky top-0 z-50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between h-16 items-center">
                <div className="flex items-center gap-8">
                  <a
                    href="https://portalskor.net"
                    className="flex items-center gap-2 group"
                  >
                    {appConfig?.logoUrl ? (
                      <img
                        src={appConfig.logoUrl}
                        alt={webName}
                        className="h-8 max-w-[120px] object-contain"
                      />
                    ) : (
                      <div className="p-2 bg-emerald-500/10 rounded-lg group-hover:bg-emerald-500/20 transition-colors">
                        <Trophy className="w-6 h-6 text-emerald-500" />
                      </div>
                    )}
                    {!appConfig?.logoUrl && (
                      <span className="font-bold text-xl tracking-tight">
                        {webName}
                      </span>
                    )}
                  </a>
                  <div className="hidden md:flex items-center gap-6">
                    <Link
                      to="/user/dashboard"
                      className="text-sm font-medium text-zinc-400 hover:text-white transition-colors"
                    >
                      Home
                    </Link>
                    {user.role === "admin" && (
                      <Link
                        to="/admin"
                        className="text-sm font-medium text-zinc-400 hover:text-white transition-colors flex items-center gap-1.5"
                      >
                        <Shield className="w-4 h-4" /> Admin
                      </Link>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="hidden sm:flex flex-col items-end mr-2">
                    <span className="text-xs text-zinc-500 font-medium uppercase tracking-wider">
                      Saldo
                    </span>
                    <span className="text-sm font-bold text-emerald-500">
                      Rp {user.balance.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-8 w-px bg-white/5 mx-2 hidden sm:block" />
                  <div className="flex items-center gap-3">
                    <div className="flex flex-col items-end">
                      <span className="text-sm font-semibold">
                        {user.username}
                      </span>
                      <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">
                        {user.role}
                      </span>
                    </div>
                    <button
                      onClick={handleSignOut}
                      className="p-2 hover:bg-white/5 rounded-full transition-colors text-zinc-400 hover:text-red-400"
                    >
                      <LogOut className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        )}

        <Routes>
          <Route
            path="/"
            element={
              <Landing
                webName={webName}
                logoUrl={appConfig?.logoUrl}
                appConfig={appConfig}
                user={user}
              />
            }
          />
          <Route
            path="/user/login"
            element={
              !user ? (
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <Login
                    webName={webName}
                    logoUrl={appConfig?.logoUrl}
                    isRegisterRoute={false}
                  />
                </main>
              ) : (
                <Navigate
                  to={user.role === "admin" ? "/admin" : "/user/dashboard"}
                />
              )
            }
          />
          <Route
            path="/user/register"
            element={
              !user ? (
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <Login
                    webName={webName}
                    logoUrl={appConfig?.logoUrl}
                    isRegisterRoute={true}
                  />
                </main>
              ) : (
                <Navigate
                  to={user.role === "admin" ? "/admin" : "/user/dashboard"}
                />
              )
            }
          />
          <Route
            path="/admin/login"
            element={
              !user ? (
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <AdminLogin webName={webName} logoUrl={appConfig?.logoUrl} />
                </main>
              ) : user.role === "admin" ? (
                <Navigate to="/admin" />
              ) : (
                <Navigate to="/user/dashboard" />
              )
            }
          />
          <Route
            path="/user/forgot-password"
            element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <ForgotPassword
                  webName={webName}
                  logoUrl={appConfig?.logoUrl}
                  role="user"
                />
              </main>
            }
          />
          <Route
            path="/user/reset-password"
            element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <ResetPassword
                  webName={webName}
                  logoUrl={appConfig?.logoUrl}
                  role="user"
                />
              </main>
            }
          />
          <Route
            path="/admin/forgot-password"
            element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <ForgotPassword
                  webName={webName}
                  logoUrl={appConfig?.logoUrl}
                  role="admin"
                />
              </main>
            }
          />
          <Route
            path="/admin/reset-password"
            element={
              <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <ResetPassword
                  webName={webName}
                  logoUrl={appConfig?.logoUrl}
                  role="admin"
                />
              </main>
            }
          />
          <Route
            path="/user/dashboard"
            element={
              user && (!user.role || user.role === "user") ? (
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <Home user={user} webName={webName} />
                </main>
              ) : (
                <Navigate
                  to={user?.role === "admin" ? "/admin" : "/user/login"}
                />
              )
            }
          />
          <Route
            path="/admin"
            element={
              user?.role === "admin" ? (
                <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <Admin webName={webName} />
                </main>
              ) : (
                <Navigate to="/admin/login" />
              )
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>

        {user && (!user.role || user.role === "user") && (
          <footer className="border-t border-white/5 py-8 mt-12 bg-zinc-900/10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center gap-6">
              <div className="flex items-center gap-6">
                {appConfig?.facebookUrl && (
                  <a
                    href={appConfig.facebookUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-zinc-500 hover:text-emerald-500 transition-colors p-2 hover:bg-emerald-500/10 rounded-full"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                )}
                {appConfig?.instagramUrl && (
                  <a
                    href={appConfig.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-zinc-500 hover:text-emerald-500 transition-colors p-2 hover:bg-emerald-500/10 rounded-full"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                )}
                {appConfig?.tiktokUrl && (
                  <a
                    href={appConfig.tiktokUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-zinc-500 hover:text-emerald-500 transition-colors p-2 hover:bg-emerald-500/10 rounded-full"
                  >
                    <Music4 className="w-5 h-5" />
                  </a>
                )}
                {appConfig?.youtubeUrl && (
                  <a
                    href={appConfig.youtubeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-zinc-500 hover:text-emerald-500 transition-colors p-2 hover:bg-emerald-500/10 rounded-full"
                  >
                    <Youtube className="w-5 h-5" />
                  </a>
                )}
              </div>
              <p className="text-sm font-medium text-zinc-500">
                &copy; {new Date().getFullYear()} {webName}. All rights
                reserved.
              </p>
            </div>
          </footer>
        )}
      </div>
    </Router>
  );
}
